angular.module("sportsStore")
    .constant("dataUrl", "http://localhost:2403/products")
    .controller("sportsStoreCtrl", function ($scope, $http, dataUrl) {
        $scope.data = {};
        $http({
            method: "GET",
            url: dataUrl
        }).then(function (data) {
            console.log(data);
            $scope.data.products = data.data;
        },function errorCallback(response) {
                $scope.data.error = true;
            })
    });